import { useState, useEffect, useRef } from "react";

// ── Palette de couleurs pour les créneaux ──────────────────────────
const CRENEAU_COLORS = [
  "#E63946","#457B9D","#2A9D8F","#E9C46A","#F4A261",
  "#6A0572","#1D3557","#A8DADC","#F77F00","#52B788",
  "#B5838D","#6D6875","#80B918","#0077B6","#9B2226",
];

const FILIERE_COLORS = {
  INFO: "#3A86FF", RESEAU: "#FF6B6B", SCIENCE: "#FFBE0B",
  LANGUE: "#06D6A0", default: "#8338EC",
};

// ── Données par défaut (depuis graphe.py / affectation.py) ──────────
const DEFAULT_UES = [
  { code: "INF212",  effectif: 800, necessite_labo: false, surveillant: "PROF_A", filiere: "INFO" },
  { code: "INF222",  effectif: 750, necessite_labo: false, surveillant: "PROF_B", filiere: "INFO" },
  { code: "INF232",  effectif: 700, necessite_labo: false, surveillant: "PROF_C", filiere: "INFO" },
  { code: "INF242",  effectif: 650, necessite_labo: false, surveillant: "PROF_D", filiere: "INFO" },
  { code: "INF252",  effectif: 600, necessite_labo: false, surveillant: "PROF_E", filiere: "INFO" },
  { code: "MAT232",  effectif: 900, necessite_labo: false, surveillant: "PROF_F", filiere: "MATH" },
  { code: "PHY232",  effectif: 500, necessite_labo: false, surveillant: "PROF_G", filiere: "SCIENCE" },
  { code: "CHM222",  effectif: 500, necessite_labo: false, surveillant: "PROF_H", filiere: "CHIMIE" },
  { code: "CHM232",  effectif: 500, necessite_labo: false, surveillant: "PROF_I", filiere: "CHIMIE" },
  { code: "ANGLAIS", effectif: 800, necessite_labo: false, surveillant: "PROF_J", filiere: "LANGUE" },
  { code: "PPE212",  effectif: 600, necessite_labo: false, surveillant: "PROF_K", filiere: "MATH" },
];

const DEFAULT_INSCRIPTIONS = {
  // L2 INFO : INF212, INF222, INF232, MAT232 en commun
  E01: ["INF212","INF222","INF232","MAT232","ANGLAIS"],
  E02: ["INF212","INF222","INF232","MAT232","PHY232"],
  E03: ["INF212","INF222","INF232","MAT232","PPE212"],
  E04: ["INF212","INF222","INF232","MAT232","CHM222"],
  E05: ["INF212","INF222","INF232","MAT232","CHM232"],
  E06: ["INF212","INF222","INF232","MAT232","INF242"],
  E07: ["INF212","INF222","INF232","MAT232","INF252"],
  E08: ["INF212","INF222","INF242","INF252","ANGLAIS"],
  E09: ["INF212","INF232","INF242","INF252","MAT232"],
  E10: ["INF222","INF232","INF242","INF252","PHY232"],
  E11: ["INF212","INF222","INF232","INF242","INF252"],
  E12: ["MAT232","PHY232","CHM222","CHM232","ANGLAIS"],
  E13: ["INF212","INF222","MAT232","PHY232","PPE212"],
  E14: ["INF232","INF242","INF252","CHM232","ANGLAIS"],
  E15: ["INF212","INF222","INF232","MAT232","PPE212"],
};

const DEFAULT_SALLES = [
  { code: "A1",    capacite: 100,  est_labo: false },
  { code: "A2",    capacite: 100,  est_labo: false },
  { code: "A250",  capacite: 250,  est_labo: false },
  { code: "A350",  capacite: 350,  est_labo: false },
  { code: "A501",  capacite: 500,  est_labo: false },
  { code: "A502",  capacite: 500,  est_labo: false },
  { code: "A750",  capacite: 750,  est_labo: false },
  { code: "A1001", capacite: 1000, est_labo: false },
  { code: "A1002", capacite: 1000, est_labo: false },
];

// ── Algorithmes JS ────────────────────────────────────────────────────
function buildConflictGraph(ues, inscriptions) {
  const ueCodes = ues.map(u => u.code);
  const adj = {};
  ueCodes.forEach(u => adj[u] = new Set());
  const added = new Set();
  Object.values(inscriptions).forEach(ueList => {
    for (let i = 0; i < ueList.length; i++) {
      for (let j = i + 1; j < ueList.length; j++) {
        const [a, b] = [ueList[i], ueList[j]].sort();
        const key = `${a}|${b}`;
        if (!added.has(key) && adj[a] !== undefined && adj[b] !== undefined) {
          added.add(key);
          adj[a].add(b);
          adj[b].add(a);
        }
      }
    }
  });
  return adj;
}

function dsatur(adj, ueCodes) {
  const coloring = {};
  const saturation = {};
  const degree = {};
  ueCodes.forEach(u => { saturation[u] = 0; degree[u] = adj[u].size; });

  for (let step = 0; step < ueCodes.length; step++) {
    // Pick uncolored vertex with max saturation (tie-break: degree, then alpha)
    const uncolored = ueCodes.filter(u => !(u in coloring));
    uncolored.sort((a, b) =>
      saturation[b] - saturation[a] || degree[b] - degree[a] || a.localeCompare(b)
    );
    const v = uncolored[0];
    // Find smallest color not used by neighbors
    const neighborColors = new Set([...adj[v]].map(n => coloring[n]).filter(c => c !== undefined));
    let c = 0;
    while (neighborColors.has(c)) c++;
    coloring[v] = c;
    // Update saturation of uncolored neighbors
    adj[v].forEach(n => {
      if (!(n in coloring)) saturation[n] = new Set([...adj[n]].map(x => coloring[x]).filter(x => x !== undefined)).size;
    });
  }
  return coloring;
}

function welshPowell(adj, ueCodes) {
  const sorted = [...ueCodes].sort((a, b) => adj[b].size - adj[a].size);
  const coloring = {};
  sorted.forEach(v => {
    const neighborColors = new Set([...adj[v]].map(n => coloring[n]).filter(c => c !== undefined));
    let c = 0;
    while (neighborColors.has(c)) c++;
    coloring[v] = c;
  });
  return coloring;
}

function bestFitAssign(coloring, ues, salles) {
  const ueMap = {};
  ues.forEach(u => ueMap[u.code] = u);
  const creneaux = {};
  Object.entries(coloring).forEach(([ue, c]) => {
    if (!creneaux[c]) creneaux[c] = [];
    creneaux[c].push(ue);
  });
  const occupation = {};
  const affectations = [];
  Object.entries(creneaux).forEach(([c, ueList]) => {
    const cNum = parseInt(c) + 1;
    const sorted = [...ueList].sort((a, b) => (ueMap[b]?.effectif || 0) - (ueMap[a]?.effectif || 0));
    sorted.forEach(code => {
      const info = ueMap[code];
      if (!info) return;
      const candidates = salles.filter(s => {
        if (info.necessite_labo && !s.est_labo) return false;
        if (s.capacite < info.effectif) return false;
        const key = `${cNum}|${s.code}`;
        return !occupation[key];
      });
      if (candidates.length === 0) {
        affectations.push({ ue_code: code, creneau: cNum, salle: null, succes: false });
      } else {
        candidates.sort((a, b) => a.capacite - b.capacite);
        const salle = candidates[0];
        occupation[`${cNum}|${salle.code}`] = true;
        affectations.push({ ue_code: code, creneau: cNum, salle, succes: true });
      }
    });
  });
  return affectations.sort((a, b) => a.creneau - b.creneau || a.ue_code.localeCompare(b.ue_code));
}

function auditAffectations(affectations, ues, coloring, adj) {
  const ueMap = {};
  ues.forEach(u => ueMap[u.code] = u);
  const violations = [];
  // C2: unicité salle par créneau
  const slotRoom = {};
  affectations.forEach(a => {
    if (!a.succes || !a.salle) return;
    const key = `${a.creneau}|${a.salle.code}`;
    if (slotRoom[key]) violations.push({ type: "OBLIGATOIRE", code: "C2", msg: `${a.salle.code} occupée 2 fois au créneau ${a.creneau}` });
    slotRoom[key] = true;
  });
  // C3: capacité
  affectations.forEach(a => {
    if (!a.succes || !a.salle) return;
    const info = ueMap[a.ue_code];
    if (info && info.effectif > a.salle.capacite)
      violations.push({ type: "OBLIGATOIRE", code: "C3", msg: `${a.ue_code} : effectif ${info.effectif} > cap. ${a.salle.capacite}` });
  });
  // C4: surveillant en 2 salles
  const survSlot = {};
  affectations.forEach(a => {
    if (!a.succes) return;
    const info = ueMap[a.ue_code];
    if (!info?.surveillant) return;
    const key = `${a.creneau}|${info.surveillant}`;
    if (survSlot[key]) violations.push({ type: "OBLIGATOIRE", code: "C4", msg: `${info.surveillant} en 2 salles au créneau ${a.creneau}` });
    survSlot[key] = true;
  });
  // C5: labo
  affectations.forEach(a => {
    if (!a.succes || !a.salle) return;
    const info = ueMap[a.ue_code];
    if (info?.necessite_labo && !a.salle.est_labo)
      violations.push({ type: "OBLIGATOIRE", code: "C5", msg: `${a.ue_code} nécessite un labo` });
  });
  // S1: filières consécutives
  const filiereCreneaux = {};
  ues.forEach(u => {
    if (!u.filiere || !(u.code in coloring)) return;
    const c = coloring[u.code] + 1;
    if (!filiereCreneaux[u.filiere]) filiereCreneaux[u.filiere] = [];
    filiereCreneaux[u.filiere].push({ creneau: c, code: u.code });
  });
  Object.entries(filiereCreneaux).forEach(([filiere, items]) => {
    items.sort((a, b) => a.creneau - b.creneau);
    for (let i = 0; i < items.length - 1; i++) {
      if (items[i + 1].creneau - items[i].creneau === 1)
        violations.push({ type: "SOUHAITEE", code: "S1", msg: `Filière ${filiere} : ${items[i].code} et ${items[i+1].code} consécutifs` });
    }
  });
  // S2: équilibre créneaux
  const chargeMap = {};
  affectations.forEach(a => { chargeMap[a.creneau] = (chargeMap[a.creneau] || 0) + 1; });
  const charges = Object.values(chargeMap);
  const moy = charges.reduce((s, v) => s + v, 0) / (charges.length || 1);
  Object.entries(chargeMap).forEach(([c, nb]) => {
    if (nb > moy * 1.5) violations.push({ type: "SOUHAITEE", code: "S2", msg: `Créneau ${c} surchargé : ${nb} examens (moy. ${moy.toFixed(1)})` });
  });
  const nb_oblig = violations.filter(v => v.type === "OBLIGATOIRE").length;
  const nb_souh  = violations.filter(v => v.type === "SOUHAITEE").length;
  return { violations, nb_obligatoires: nb_oblig, nb_souhaitees: nb_souh, conforme: nb_oblig === 0 };
}

// ── Composants UI ──────────────────────────────────────────────────────────

function Badge({ children, color = "#3A86FF" }) {
  return (
    <span style={{
      background: color + "22", color, border: `1px solid ${color}44`,
      borderRadius: 4, padding: "2px 8px", fontSize: 11, fontWeight: 700,
      letterSpacing: 0.5, textTransform: "uppercase",
    }}>{children}</span>
  );
}

function StatCard({ label, value, sub, accent = "#3A86FF" }) {
  return (
    <div style={{
      background: "#0d1117", border: `1px solid #1e2d3d`,
      borderRadius: 10, padding: "18px 22px", flex: 1, minWidth: 120,
      borderTop: `3px solid ${accent}`,
    }}>
      <div style={{ color: "#8b9ab0", fontSize: 11, textTransform: "uppercase", letterSpacing: 1 }}>{label}</div>
      <div style={{ color: "#e6edf3", fontSize: 28, fontWeight: 800, lineHeight: 1.2, marginTop: 4 }}>{value}</div>
      {sub && <div style={{ color: "#556070", fontSize: 12, marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function GraphCanvas({ adj, ues, coloring }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !adj || !container) return;
    // Adapt to container width
    const size = Math.min(container.clientWidth || 340, 500);
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d");
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const ueCodes = ues.map(u => u.code);
    const n = ueCodes.length;
    const cx = W / 2, cy = H / 2, r = Math.min(W, H) * 0.36;

    // Positions circulaires
    const pos = {};
    ueCodes.forEach((code, i) => {
      const angle = (2 * Math.PI * i) / n - Math.PI / 2;
      pos[code] = { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
    });

    // Arêtes
    ctx.strokeStyle = "#2a3a4a";
    ctx.lineWidth = 1;
    ueCodes.forEach(u => {
      adj[u].forEach(v => {
        if (u < v) {
          ctx.beginPath();
          ctx.moveTo(pos[u].x, pos[u].y);
          ctx.lineTo(pos[v].x, pos[v].y);
          ctx.stroke();
        }
      });
    });

    // Nœuds
    ueCodes.forEach(code => {
      const { x, y } = pos[code];
      const c = coloring ? coloring[code] : undefined;
      const color = c !== undefined ? CRENEAU_COLORS[c % CRENEAU_COLORS.length] : "#3A86FF";

      ctx.beginPath();
      ctx.arc(x, y, 22, 0, 2 * Math.PI);
      ctx.fillStyle = color + "dd";
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = "#fff";
      ctx.font = "bold 10px monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(code.length > 6 ? code.slice(0, 5) + "…" : code, x, y);
    });
  }, [adj, ues, coloring]);

  return (
    <div ref={containerRef} style={{ width: "100%" }}>
      <canvas ref={canvasRef}
        style={{ borderRadius: 8, background: "#0a0f16", display: "block", width: "100%", height: "auto" }} />
    </div>
  );
}

// ── Section d'édition des données ──────────────────────────────────────
function DataEditor({ ues, setUes, inscriptions, setInscriptions, salles, setSalles }) {
  const [tab, setTab] = useState("ues");
  const [newUe, setNewUe] = useState({ code: "", effectif: "", necessite_labo: false, surveillant: "", filiere: "" });
  const [newSalle, setNewSalle] = useState({ code: "", capacite: "", est_labo: false });
  const [insc_etudiant, setInscEtudiant] = useState("");
  const [insc_ues, setInscUes] = useState("");

  const addUe = () => {
    if (!newUe.code || !newUe.effectif) return;
    setUes(prev => [...prev, { ...newUe, effectif: parseInt(newUe.effectif) }]);
    setNewUe({ code: "", effectif: "", necessite_labo: false, surveillant: "", filiere: "" });
  };

  const addSalle = () => {
    if (!newSalle.code || !newSalle.capacite) return;
    setSalles(prev => [...prev, { ...newSalle, capacite: parseInt(newSalle.capacite) }]);
    setNewSalle({ code: "", capacite: "", est_labo: false });
  };

  const addInscription = () => {
    if (!insc_etudiant || !insc_ues) return;
    const ueList = insc_ues.split(",").map(s => s.trim()).filter(Boolean);
    setInscriptions(prev => ({ ...prev, [insc_etudiant]: ueList }));
    setInscEtudiant(""); setInscUes("");
  };

  const tabStyle = (t) => ({
    padding: "8px 18px", cursor: "pointer", fontSize: 13, fontWeight: 600,
    background: tab === t ? "#1e2d3d" : "transparent",
    color: tab === t ? "#58a6ff" : "#8b9ab0",
    border: "none", borderBottom: tab === t ? "2px solid #58a6ff" : "2px solid transparent",
    transition: "all .15s",
  });

  const inputStyle = {
    background: "#0d1117", border: "1px solid #2a3a4a", borderRadius: 6,
    color: "#e6edf3", padding: "7px 10px", fontSize: 13, outline: "none",
  };

  return (
    <div style={{ background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, overflow: "hidden" }}>
      <div style={{ display: "flex", borderBottom: "1px solid #1e2d3d", padding: "0 8px" }}>
        {[["ues","UE"], ["inscriptions","Inscriptions"], ["salles","Salles"]].map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)} style={tabStyle(k)}>{label}</button>
        ))}
      </div>

      <div style={{ padding: 20 }}>
        {tab === "ues" && (
          <>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                <thead>
                  <tr>{["Code","Effectif","Labo","Surveillant","Filière",""].map(h => (
                    <th key={h} style={{ color: "#8b9ab0", textAlign: "left", padding: "6px 10px", borderBottom: "1px solid #1e2d3d", fontWeight: 600 }}>{h}</th>
                  ))}</tr>
                </thead>
                <tbody>
                  {ues.map((u, i) => (
                    <tr key={u.code} style={{ borderBottom: "1px solid #1e2d3d11" }}>
                      <td style={{ padding: "7px 10px", color: "#58a6ff", fontWeight: 700, fontFamily: "monospace" }}>{u.code}</td>
                      <td style={{ padding: "7px 10px", color: "#e6edf3" }}>{u.effectif}</td>
                      <td style={{ padding: "7px 10px" }}><Badge color={u.necessite_labo ? "#FF6B6B" : "#2A9D8F"}>{u.necessite_labo ? "Oui" : "Non"}</Badge></td>
                      <td style={{ padding: "7px 10px", color: "#8b9ab0" }}>{u.surveillant}</td>
                      <td style={{ padding: "7px 10px" }}><Badge color={FILIERE_COLORS[u.filiere] || FILIERE_COLORS.default}>{u.filiere}</Badge></td>
                      <td style={{ padding: "7px 10px" }}>
                        <button onClick={() => setUes(prev => prev.filter((_, j) => j !== i))}
                          style={{ background: "none", border: "none", color: "#E63946", cursor: "pointer", fontSize: 16 }}>×</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap", alignItems: "center" }}>
              {[["code","Code UE"],["effectif","Effectif"],["surveillant","Surveillant"],["filiere","Filière"]].map(([k, ph]) => (
                <input key={k} placeholder={ph} value={newUe[k]} onChange={e => setNewUe(p => ({...p, [k]: e.target.value}))}
                  style={{ ...inputStyle, width: k === "code" ? 90 : 100 }} />
              ))}
              <label style={{ color: "#8b9ab0", fontSize: 13, display: "flex", alignItems: "center", gap: 5 }}>
                <input type="checkbox" checked={newUe.necessite_labo} onChange={e => setNewUe(p => ({...p, necessite_labo: e.target.checked}))} />
                Labo
              </label>
              <button onClick={addUe} style={{ background: "#238636", color: "#fff", border: "none", borderRadius: 6, padding: "8px 16px", cursor: "pointer", fontWeight: 600 }}>
                + Ajouter UE
              </button>
            </div>
          </>
        )}

        {tab === "inscriptions" && (
          <>
            <div style={{ maxHeight: 280, overflowY: "auto" }}>
              {Object.entries(inscriptions).map(([etu, ueList]) => (
                <div key={etu} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0", borderBottom: "1px solid #1e2d3d22" }}>
                  <span style={{ color: "#58a6ff", fontFamily: "monospace", width: 40 }}>{etu}</span>
                  <div style={{ display: "flex", gap: 4, flex: 1, flexWrap: "wrap" }}>
                    {ueList.map(u => <Badge key={u} color="#6A0572">{u}</Badge>)}
                  </div>
                  <button onClick={() => setInscriptions(p => { const n = {...p}; delete n[etu]; return n; })}
                    style={{ background: "none", border: "none", color: "#E63946", cursor: "pointer" }}>×</button>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 14, alignItems: "center" }}>
              <input placeholder="Étudiant (ex: E13)" value={insc_etudiant} onChange={e => setInscEtudiant(e.target.value)} style={{ ...inputStyle, width: 120 }} />
              <input placeholder="UE séparées par virgules" value={insc_ues} onChange={e => setInscUes(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
              <button onClick={addInscription} style={{ background: "#238636", color: "#fff", border: "none", borderRadius: 6, padding: "8px 16px", cursor: "pointer", fontWeight: 600 }}>
                + Ajouter
              </button>
            </div>
          </>
        )}

        {tab === "salles" && (
          <>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              {salles.map((s, i) => (
                <div key={s.code} style={{
                  background: "#0d1117", border: `1px solid ${s.est_labo ? "#FF6B6B44" : "#2a3a4a"}`,
                  borderRadius: 8, padding: "12px 16px", minWidth: 110, position: "relative",
                }}>
                  <button onClick={() => setSalles(p => p.filter((_, j) => j !== i))}
                    style={{ position: "absolute", top: 4, right: 6, background: "none", border: "none", color: "#E63946", cursor: "pointer", fontSize: 14 }}>×</button>
                  <div style={{ color: "#58a6ff", fontWeight: 700, fontFamily: "monospace" }}>{s.code}</div>
                  <div style={{ color: "#8b9ab0", fontSize: 12 }}>Cap. {s.capacite}</div>
                  <Badge color={s.est_labo ? "#FF6B6B" : "#2A9D8F"}>{s.est_labo ? "Labo" : "Standard"}</Badge>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 14, alignItems: "center" }}>
              <input placeholder="Code salle" value={newSalle.code} onChange={e => setNewSalle(p => ({...p, code: e.target.value}))} style={{ ...inputStyle, width: 110 }} />
              <input placeholder="Capacité" type="number" value={newSalle.capacite} onChange={e => setNewSalle(p => ({...p, capacite: e.target.value}))} style={{ ...inputStyle, width: 90 }} />
              <label style={{ color: "#8b9ab0", fontSize: 13, display: "flex", alignItems: "center", gap: 5 }}>
                <input type="checkbox" checked={newSalle.est_labo} onChange={e => setNewSalle(p => ({...p, est_labo: e.target.checked}))} /> Labo
              </label>
              <button onClick={addSalle} style={{ background: "#238636", color: "#fff", border: "none", borderRadius: 6, padding: "8px 16px", cursor: "pointer", fontWeight: 600 }}>
                + Ajouter Salle
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── Planning Heatmap ──────────────────────────────────────────────────────
function PlanningGrid({ affectations, ues, salles }) {
  if (!affectations.length) return null;
  const ueMap = {}; ues.forEach(u => ueMap[u.code] = u);
  const allCreneaux = [...new Set(affectations.map(a => a.creneau))].sort((a, b) => a - b);
  const allSalles   = salles.map(s => s.code);
  const grid = {};
  affectations.forEach(a => { if (a.succes && a.salle) grid[`${a.creneau}|${a.salle.code}`] = a; });

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ borderCollapse: "collapse", fontSize: 12, minWidth: 500 }}>
        <thead>
          <tr>
            <th style={{ background: "#0d1117", color: "#8b9ab0", padding: "8px 14px", border: "1px solid #1e2d3d", minWidth: 60 }}>Créneau</th>
            {allSalles.map(s => {
              const salle = salles.find(sl => sl.code === s);
              return (
                <th key={s} style={{ background: "#0d1117", color: "#8b9ab0", padding: "8px 14px", border: "1px solid #1e2d3d", whiteSpace: "nowrap" }}>
                  {s}<br/><span style={{ fontSize: 10, color: "#556070" }}>cap.{salle?.capacite} {salle?.est_labo ? "🔬" : ""}</span>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {allCreneaux.map(c => (
            <tr key={c}>
              <td style={{ background: "#0d1117", color: CRENEAU_COLORS[(c-1) % CRENEAU_COLORS.length], fontWeight: 800, padding: "8px 14px", border: "1px solid #1e2d3d", textAlign: "center" }}>
                C{c}
              </td>
              {allSalles.map(s => {
                const a = grid[`${c}|${s}`];
                if (!a) return <td key={s} style={{ border: "1px solid #1e2d3d11", background: "#0a0f1600" }}></td>;
                const info = ueMap[a.ue_code];
                const color = FILIERE_COLORS[info?.filiere] || FILIERE_COLORS.default;
                return (
                  <td key={s} style={{ border: "1px solid #1e2d3d", background: color + "22", padding: "8px 12px", verticalAlign: "top" }}>
                    <div style={{ color, fontWeight: 800, fontFamily: "monospace" }}>{a.ue_code}</div>
                    <div style={{ color: "#8b9ab0", fontSize: 11 }}>{info?.effectif} ét.</div>
                    <div style={{ color: "#556070", fontSize: 11 }}>{info?.filiere}</div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Chatbot IA ──────────────────────────────────────────────────────────────
function AIChatbot({ context, externalInput, onExternalInputConsumed }) {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Bonjour ! Je suis votre assistant IA spécialisé en planification d'examens et théorie des graphes. Posez-moi vos questions sur votre planning ou les algorithmes utilisés." }
  ]);
  const [input, setInput] = useState("");
  
  useEffect(() => {
    if (externalInput) {
      setInput(externalInput);
      onExternalInputConsumed && onExternalInputConsumed();
    }
  }, [externalInput]);
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: "user", content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);
    try {
      const systemPrompt = `Tu es un assistant expert en théorie des graphes et planification d'examens universitaires.
Voici le contexte actuel du planning :
${context}

Réponds en français, de façon précise et pédagogique. Si on te demande des modifications, explique comment les interpréter dans le contexte des algorithmes (Welsh-Powell, DSATUR, Best Fit).`;

      const history = [...messages, userMsg].slice(-10);
      const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY || "";
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: systemPrompt,
          messages: history.map(m => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await response.json();
      const reply = data.content?.find(b => b.type === "text")?.text || data.error?.message || "Désolé, une erreur s'est produite.";
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: "assistant", content: "Erreur de connexion à l'API." }]);
    }
    setLoading(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: 420, background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, overflow: "hidden" }}>
      <div style={{ padding: "12px 16px", borderBottom: "1px solid #1e2d3d", display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#2A9D8F" }} />
        <span style={{ color: "#e6edf3", fontWeight: 700, fontSize: 14 }}>Assistant IA — Analyse du Planning</span>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{
              maxWidth: "80%", padding: "10px 14px", borderRadius: m.role === "user" ? "14px 14px 4px 14px" : "14px 14px 14px 4px",
              background: m.role === "user" ? "#238636" : "#1e2d3d",
              color: "#e6edf3", fontSize: 13, lineHeight: 1.6, whiteSpace: "pre-wrap",
            }}>{m.content}</div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex" }}>
            <div style={{ background: "#1e2d3d", padding: "10px 14px", borderRadius: "14px 14px 14px 4px", color: "#58a6ff" }}>
              <span style={{ animation: "pulse 1s infinite" }}>●●●</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div style={{ padding: 12, borderTop: "1px solid #1e2d3d", display: "flex", gap: 8 }}>
        <input
          value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && send()}
          placeholder="Posez une question sur le planning, les algorithmes..."
          style={{ flex: 1, background: "#0d1117", border: "1px solid #2a3a4a", borderRadius: 8, padding: "9px 14px", color: "#e6edf3", fontSize: 13, outline: "none" }}
        />
        <button onClick={send} disabled={loading}
          style={{ background: "#238636", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", cursor: "pointer", fontWeight: 700, opacity: loading ? 0.5 : 1 }}>
          →
        </button>
      </div>
    </div>
  );
}

// ── AI Tab avec suggestions fonctionnelles ────────────────────────────────
function AITab({ context }) {
  const [pendingQ, setPendingQ] = useState("");
  const [key, setKey] = useState(0);
  const suggestions = [
    "Explique l'algorithme DSATUR",
    "Pourquoi 8 créneaux minimum ?",
    "Comment réduire les avertissements S1 ?",
    "Compare Welsh-Powell et DSATUR",
  ];
  return (
    <div>
      <h2 style={{ color: "#e6edf3", fontSize: 18, margin: "0 0 8px" }}>Assistant IA</h2>
      <p style={{ color: "#8b9ab0", fontSize: 13, margin: "0 0 16px" }}>
        Posez vos questions sur le planning, les algorithmes, ou demandez des explications sur les résultats.
      </p>
      <AIChatbot
        context={context}
        externalInput={pendingQ}
        onExternalInputConsumed={() => setPendingQ("")}
      />
      <div style={{ marginTop: 14, display: "flex", gap: 8, flexWrap: "wrap" }}>
        {suggestions.map(q => (
          <button key={q} onClick={() => setPendingQ(q)} style={{
            background: "#161b22", border: "1px solid #2a3a4a", color: "#8b9ab0",
            borderRadius: 20, padding: "8px 14px", cursor: "pointer", fontSize: 12,
            transition: "all .15s",
          }}>{q}</button>
        ))}
      </div>
    </div>
  );
}

// ── App principale ──────────────────────────────────────────────────────────
export default function App() {
  const [ues, setUes] = useState(DEFAULT_UES);
  const [inscriptions, setInscriptions] = useState(DEFAULT_INSCRIPTIONS);
  const [salles, setSalles] = useState(DEFAULT_SALLES);
  const [algo, setAlgo] = useState("dsatur");
  const [results, setResults] = useState(null);
  const [running, setRunning] = useState(false);
  const [activeTab, setActiveTab] = useState("data");

  const runPipeline = () => {
    setRunning(true);
    setTimeout(() => {
      const ueCodes = ues.map(u => u.code);
      const adj = buildConflictGraph(ues, inscriptions);
      const coloring = algo === "dsatur" ? dsatur(adj, ueCodes) : welshPowell(adj, ueCodes);
      const coloringWP = welshPowell(adj, ueCodes);
      const coloringDS = dsatur(adj, ueCodes);
      const nbCreneauxWP = Math.max(...Object.values(coloringWP)) + 1;
      const nbCreneauxDS = Math.max(...Object.values(coloringDS)) + 1;
      const affectations = bestFitAssign(coloring, ues, salles);
      const audit = auditAffectations(affectations, ues, coloring, adj);
      const degrees = {};
      ueCodes.forEach(u => degrees[u] = adj[u].size);
      const nbAretes = Object.values(adj).reduce((s, v) => s + v.size, 0) / 2;
      const densite = ueCodes.length > 1 ? nbAretes / (ueCodes.length * (ueCodes.length - 1) / 2) : 0;
      setResults({ adj, coloring, coloringWP, coloringDS, affectations, audit, nbCreneauxWP, nbCreneauxDS, degrees, nbAretes, densite });
      setRunning(false);
      setActiveTab("planning");
    }, 100);
  };

  const buildContext = () => {
    if (!results) return "Aucun résultat encore calculé.";
    const { coloring, affectations, audit, nbCreneauxWP, nbCreneauxDS, nbAretes, densite } = results;
    const nb = Math.max(...Object.values(coloring)) + 1;
    return `
Graphe : ${ues.length} UE, ${nbAretes} arêtes, densité ${densite.toFixed(3)}
Algorithme utilisé : ${algo.toUpperCase()} → ${nb} créneaux
Welsh-Powell : ${nbCreneauxWP} créneaux | DSATUR : ${nbCreneauxDS} créneaux
Affectations :
${affectations.map(a => `  ${a.ue_code} → Créneau ${a.creneau} | ${a.succes ? a.salle.code : "ÉCHEC"}`).join("\n")}
Audit : ${audit.conforme ? "CONFORME" : "NON CONFORME"} | Violations oblig. : ${audit.nb_obligatoires} | Avertissements : ${audit.nb_souhaitees}
${audit.violations.map(v => `  [${v.code}] ${v.msg}`).join("\n")}
    `.trim();
  };

  const navItems = [
    ["data", "Données"],
    ["graph", "Graphe"],
    ["planning", "Planning"],
    ["audit", "Audit"],
    ["ai", "Assistant IA"],
  ];

  const navStyle = (k) => ({
    padding: "10px 20px", cursor: "pointer", fontSize: 13, fontWeight: 600,
    background: activeTab === k ? "#1e2d3d" : "transparent",
    color: activeTab === k ? "#58a6ff" : "#8b9ab0",
    border: "none", borderBottom: activeTab === k ? "2px solid #58a6ff" : "2px solid transparent",
    transition: "all .15s",
  });

  return (
    <div style={{ minHeight: "100vh", background: "#0d1117", fontFamily: "'JetBrains Mono', 'Fira Code', monospace", color: "#e6edf3" }}>
      <style>{`
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #0d1117; }
        ::-webkit-scrollbar-thumb { background: #2a3a4a; border-radius: 3px; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        .hdr { background:#161b22; border-bottom:1px solid #1e2d3d; padding:12px 16px; display:flex; flex-direction:column; gap:10px; }
        .hdr-top { display:flex; align-items:center; gap:10px; }
        .hdr-actions { display:flex; gap:8px; }
        .nav-bar { background:#161b22; border-bottom:1px solid #1e2d3d; display:flex; overflow-x:auto; -webkit-overflow-scrolling:touch; scrollbar-width:none; padding:0 8px; }
        .nav-bar::-webkit-scrollbar { display:none; }
        .nav-btn { white-space:nowrap; flex-shrink:0; padding:10px 14px; cursor:pointer; font-size:12px; font-weight:600; background:transparent; border:none; border-bottom:2px solid transparent; transition:all .15s; }
        .nav-btn.active { background:#1e2d3d; color:#58a6ff; border-bottom-color:#58a6ff; }
        .nav-btn:not(.active) { color:#8b9ab0; }
        .stats-bar { background:#161b22; border-bottom:1px solid #1e2d3d; padding:10px 16px; display:flex; gap:8px; overflow-x:auto; -webkit-overflow-scrolling:touch; }
        .content { padding:16px; max-width:1200px; margin:0 auto; animation:fadeIn .2s; }
        @media(min-width:600px){
          .hdr { flex-direction:row; align-items:center; padding:16px 24px; }
          .hdr-actions { margin-left:auto; }
          .content { padding:24px 32px; }
          .graph-grid { grid-template-columns: 1fr 1fr !important; }
          .desc-grid { grid-template-columns: 1fr !important; }
        }
        .audit-cards { display:flex; gap:12px; margin-bottom:20px; }
        .audit-card { flex:1; min-width:90px; }
        .aff-card { display:flex; flex-wrap:wrap; gap:6px; align-items:center; }
      `}</style>

      {/* Header */}
      <div className="hdr">
        <div className="hdr-top">
          <div style={{ width:36, height:36, borderRadius:"50%", background:"linear-gradient(135deg,#3A86FF,#E63946)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 }}>🎓</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ color:"#e6edf3", fontWeight:800, fontSize:15 }}>Planification d'Examens</div>
            <div style={{ color:"#8b9ab0", fontSize:10 }}>Coloration de graphes · L2 Informatique · UY</div>
          </div>
        </div>
        <div className="hdr-actions">
          <select value={algo} onChange={e => setAlgo(e.target.value)}
            style={{ background:"#0d1117", border:"1px solid #2a3a4a", color:"#e6edf3", borderRadius:6, padding:"8px 10px", fontSize:13, outline:"none", flex:1 }}>
            <option value="dsatur">DSATUR</option>
            <option value="welsh_powell">Welsh-Powell</option>
          </select>
          <button onClick={runPipeline} disabled={running} style={{
            background: running ? "#161b22" : "linear-gradient(135deg,#238636,#2ea043)",
            color:"#fff", border:"none", borderRadius:8, padding:"9px 14px",
            cursor: running ? "wait" : "pointer", fontWeight:700, fontSize:13,
            display:"flex", alignItems:"center", gap:6, whiteSpace:"nowrap",
          }}>
            {running ? <><span style={{ animation:"spin 1s linear infinite", display:"inline-block" }}>⟳</span> Calcul…</> : "▶ Lancer"}
          </button>
        </div>
      </div>

      {/* Stats bar */}
      {results && (
        <div className="stats-bar">
          {[
            ["UE", ues.length, "#3A86FF"],
            ["Étudiants", Object.keys(inscriptions).length, "#2A9D8F"],
            ["Arêtes", results.nbAretes, "#E9C46A"],
            ["Créneaux", Math.max(...Object.values(results.coloring))+1, "#E63946"],
            ["Affectées", `${results.affectations.filter(a=>a.succes).length}/${ues.length}`, "#06D6A0"],
            ["Audit", results.audit.conforme ? "✓" : "✗", results.audit.conforme ? "#238636" : "#E63946"],
          ].map(([label, value, accent]) => (
            <div key={label} style={{ background:"#0d1117", border:`1px solid #1e2d3d`, borderTop:`3px solid ${accent}`, borderRadius:8, padding:"10px 14px", minWidth:80, flexShrink:0 }}>
              <div style={{ color:"#8b9ab0", fontSize:10, textTransform:"uppercase", letterSpacing:0.5 }}>{label}</div>
              <div style={{ color:"#e6edf3", fontSize:20, fontWeight:800 }}>{value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Nav tabs */}
      <div className="nav-bar">
        {navItems.map(([k, label]) => (
          <button key={k} onClick={() => setActiveTab(k)} className={`nav-btn${activeTab===k?" active":""}`}>{label}</button>
        ))}
      </div>

      {/* Content */}
      <div className="content">

        {activeTab === "data" && (
          <div>
            <div style={{ marginBottom: 20 }}>
              <h2 style={{ color: "#e6edf3", fontSize: 18, margin: "0 0 6px" }}>Saisie des données</h2>
              <p style={{ color: "#8b9ab0", fontSize: 13, margin: 0 }}>Modifiez les UE, inscriptions étudiants et salles disponibles, puis lancez le pipeline.</p>
            </div>
            <DataEditor ues={ues} setUes={setUes} inscriptions={inscriptions} setInscriptions={setInscriptions} salles={salles} setSalles={setSalles} />
            <div style={{ marginTop: 20, padding: 16, background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 10 }}>
              <div style={{ color: "#8b9ab0", fontSize: 12 }}>
                <strong style={{ color: "#58a6ff" }}>Format CSV attendu par main.py :</strong><br/>
                <code style={{ display: "block", marginTop: 6, color: "#e6edf3" }}>ues.csv → colonne "code_ue"</code>
                <code style={{ display: "block", color: "#e6edf3" }}>inscriptions.csv → colonnes "etudiant_id", "code_ue"</code>
              </div>
            </div>
          </div>
        )}

        {activeTab === "graph" && (
          <div>
            <h2 style={{ color: "#e6edf3", fontSize: 18, margin: "0 0 20px" }}>Graphe de conflits</h2>
            {!results ? (
              <div style={{ color: "#8b9ab0", textAlign: "center", padding: 60, border: "1px dashed #1e2d3d", borderRadius: 12 }}>
                Lancez le pipeline pour visualiser le graphe.
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 16 }} className="graph-grid">
                <div style={{ background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, padding: 16 }}>
                  <div style={{ color: "#8b9ab0", fontSize: 12, marginBottom: 12 }}>Coloration DSATUR (créneaux = couleurs)</div>
                  <div style={{ display: "flex", justifyContent: "center", overflowX: "auto" }}>
                    <GraphCanvas adj={results.adj} ues={ues} coloring={results.coloringDS} />
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 16 }} className="desc-grid">
                  <div style={{ background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, padding: 16 }}>
                    <div style={{ color: "#8b9ab0", fontSize: 11, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>Descripteurs du graphe</div>
                    <table style={{ width: "100%", fontSize: 13, borderCollapse: "collapse" }}>
                      {[
                        ["Sommets |V|", ues.length],
                        ["Arêtes |E|", results.nbAretes],
                        ["Degré max Δ(G)", Math.max(...Object.values(results.degrees))],
                        ["Degré moyen", (Object.values(results.degrees).reduce((s,v)=>s+v,0)/ues.length).toFixed(1)],
                        ["Densité", results.densite.toFixed(4)],
                        ["χ(G) — créneaux", Math.max(...Object.values(results.coloring))+1],
                      ].map(([k, v]) => (
                        <tr key={k} style={{ borderBottom: "1px solid #1e2d3d22" }}>
                          <td style={{ padding: "7px 0", color: "#8b9ab0" }}>{k}</td>
                          <td style={{ padding: "7px 0", color: "#58a6ff", fontWeight: 700, textAlign: "right", fontFamily: "monospace" }}>{v}</td>
                        </tr>
                      ))}
                    </table>
                  </div>
                  <div style={{ background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, padding: 20 }}>
                    <div style={{ color: "#8b9ab0", fontSize: 11, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>Benchmark comparatif</div>
                    {[
                      ["Welsh-Powell", results.nbCreneauxWP, "#E9C46A", "Statique (tri initial)"],
                      ["DSATUR",       results.nbCreneauxDS, "#3A86FF", "Dynamique (recalcul)"],
                    ].map(([name, nb, color, desc]) => (
                      <div key={name} style={{ marginBottom: 14 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                          <span style={{ color, fontWeight: 700, fontSize: 13 }}>{name}</span>
                          <span style={{ color: "#e6edf3", fontWeight: 700 }}>{nb} créneaux</span>
                        </div>
                        <div style={{ background: "#0d1117", borderRadius: 4, height: 8, overflow: "hidden" }}>
                          <div style={{ height: "100%", width: `${(nb / 15) * 100}%`, background: color, borderRadius: 4 }} />
                        </div>
                        <div style={{ color: "#556070", fontSize: 11, marginTop: 2 }}>{desc}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "planning" && (
          <div>
            <h2 style={{ color: "#e6edf3", fontSize: 18, margin: "0 0 20px" }}>Planning des examens</h2>
            {!results ? (
              <div style={{ color: "#8b9ab0", textAlign: "center", padding: 60, border: "1px dashed #1e2d3d", borderRadius: 12 }}>
                Lancez le pipeline pour générer le planning.
              </div>
            ) : (
              <>
                <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
                  {Object.entries(FILIERE_COLORS).filter(([k]) => k !== "default").map(([filiere, color]) => (
                    <Badge key={filiere} color={color}>{filiere}</Badge>
                  ))}
                </div>
                <div style={{ background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, padding: 20, overflowX: "auto" }}>
                  <PlanningGrid affectations={results.affectations} ues={ues} salles={salles} />
                </div>
                <div style={{ marginTop: 16, background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, padding: 16 }}>
                  <div style={{ color: "#8b9ab0", fontSize: 11, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>Détail des affectations</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {results.affectations.map(a => {
                      const info = ues.find(u => u.code === a.ue_code);
                      return (
                        <div key={a.ue_code} style={{
                          background: "#0d1117", borderRadius: 8, padding: "10px 14px",
                          border: `1px solid ${a.succes ? "#1e2d3d" : "#E6394633"}`,
                          display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center",
                        }}>
                          <span style={{ color: "#58a6ff", fontWeight: 800, fontFamily: "monospace", minWidth: 70 }}>{a.ue_code}</span>
                          <Badge color={CRENEAU_COLORS[(a.creneau-1) % CRENEAU_COLORS.length]}>C{a.creneau}</Badge>
                          <span style={{ color: "#e6edf3", fontSize: 13 }}>{a.succes ? a.salle.code : "—"}</span>
                          <span style={{ color: "#8b9ab0", fontSize: 12 }}>{info?.effectif} ét.</span>
                          <Badge color={FILIERE_COLORS[info?.filiere] || FILIERE_COLORS.default}>{info?.filiere}</Badge>
                          <Badge color={a.succes ? "#238636" : "#E63946"}>{a.succes ? "✓ OK" : "✗ ÉCHEC"}</Badge>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {activeTab === "audit" && (
          <div>
            <h2 style={{ color: "#e6edf3", fontSize: 18, margin: "0 0 20px" }}>Rapport d'audit</h2>
            {!results ? (
              <div style={{ color: "#8b9ab0", textAlign: "center", padding: 60, border: "1px dashed #1e2d3d", borderRadius: 12 }}>
                Lancez le pipeline pour générer le rapport d'audit.
              </div>
            ) : (
              <>
                <div className="audit-cards">
                  <div className="audit-card" style={{
                    background: results.audit.conforme ? "#23863622" : "#E6394622",
                    border: `1px solid ${results.audit.conforme ? "#238636" : "#E63946"}44`,
                    borderRadius: 10, padding: "14px", textAlign: "center",
                  }}>
                    <div style={{ fontSize: 28 }}>{results.audit.conforme ? "✅" : "❌"}</div>
                    <div style={{ color: results.audit.conforme ? "#2ea043" : "#E63946", fontWeight: 800, fontSize: 14, marginTop: 4 }}>
                      {results.audit.conforme ? "CONFORME" : "NON CONFORME"}
                    </div>
                  </div>
                  <div className="audit-card" style={{ background:"#0d1117", border:"1px solid #1e2d3d", borderTop:"3px solid #E63946", borderRadius:10, padding:"14px", textAlign:"center" }}>
                    <div style={{ color:"#8b9ab0", fontSize:10, textTransform:"uppercase" }}>Violations</div>
                    <div style={{ color:"#e6edf3", fontSize:24, fontWeight:800 }}>{results.audit.nb_obligatoires}</div>
                  </div>
                  <div className="audit-card" style={{ background:"#0d1117", border:"1px solid #1e2d3d", borderTop:"3px solid #E9C46A", borderRadius:10, padding:"14px", textAlign:"center" }}>
                    <div style={{ color:"#8b9ab0", fontSize:10, textTransform:"uppercase" }}>Avert.</div>
                    <div style={{ color:"#e6edf3", fontSize:24, fontWeight:800 }}>{results.audit.nb_souhaitees}</div>
                  </div>
                </div>

                {/* Contraintes tableau */}
                <div style={{ background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, padding: 20, marginBottom: 20 }}>
                  <div style={{ color: "#8b9ab0", fontSize: 11, marginBottom: 14, textTransform: "uppercase", letterSpacing: 1 }}>Contraintes vérifiées</div>
                  {[
                    ["C1","Obligatoire","Un étudiant compose au plus une UE par créneau"],
                    ["C2","Obligatoire","Une salle accueille au plus un examen par créneau"],
                    ["C3","Obligatoire","L'effectif ne dépasse pas la capacité de la salle"],
                    ["C4","Obligatoire","Un surveillant n'est pas dans deux salles simultanément"],
                    ["C5","Obligatoire","Les UE nécessitant un labo sont affectées à un labo"],
                    ["S1","Souhaitée","Pas deux examens d'une même filière en créneaux consécutifs"],
                    ["S2","Souhaitée","Charge équilibrée (pas de créneau > 1,5× la moyenne)"],
                  ].map(([code, type, desc]) => {
                    const viol = results.audit.violations.filter(v => v.code === code);
                    const ok = viol.length === 0;
                    return (
                      <div key={code} style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 0", borderBottom: "1px solid #1e2d3d22" }}>
                        <Badge color={type === "Obligatoire" ? "#E63946" : "#E9C46A"}>{code}</Badge>
                        <span style={{ color: ok ? "#2ea043" : (type === "Obligatoire" ? "#E63946" : "#E9C46A"), fontSize: 16 }}>{ok ? "✓" : "⚠"}</span>
                        <span style={{ color: "#8b9ab0", fontSize: 13, flex: 1 }}>{desc}</span>
                        {!ok && <span style={{ color: "#556070", fontSize: 12 }}>{viol.length} violation(s)</span>}
                      </div>
                    );
                  })}
                </div>

                {results.audit.violations.length > 0 && (
                  <div style={{ background: "#161b22", border: "1px solid #1e2d3d", borderRadius: 12, padding: 20 }}>
                    <div style={{ color: "#8b9ab0", fontSize: 11, marginBottom: 14, textTransform: "uppercase", letterSpacing: 1 }}>Détail des violations</div>
                    {results.audit.violations.map((v, i) => (
                      <div key={i} style={{
                        display: "flex", gap: 12, alignItems: "flex-start", padding: "10px 12px", marginBottom: 8,
                        background: v.type === "OBLIGATOIRE" ? "#E6394611" : "#E9C46A11",
                        border: `1px solid ${v.type === "OBLIGATOIRE" ? "#E6394633" : "#E9C46A33"}`,
                        borderRadius: 8,
                      }}>
                        <Badge color={v.type === "OBLIGATOIRE" ? "#E63946" : "#E9C46A"}>{v.code}</Badge>
                        <span style={{ color: "#e6edf3", fontSize: 13 }}>{v.msg}</span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {activeTab === "ai" && (
          <AITab context={buildContext()} />
        )}
      </div>
    </div>
  );
}
