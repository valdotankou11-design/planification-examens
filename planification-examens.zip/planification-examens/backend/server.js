/**
 * server.js — Proxy sécurisé pour l'API Anthropic
 * Planification d'Examens par Coloration de Graphes
 *
 * Rôle : Recevoir les requêtes du frontend, ajouter la clé API
 * côté serveur (jamais exposée au client), et retourner la réponse.
 */

import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import Anthropic from "@anthropic-ai/sdk";
import { config } from "dotenv";

config(); // Charge .env

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Sécurité de base ─────────────────────────────────────────────────────────

// CORS : en production, remplacez "*" par votre domaine Vercel
const corsOptions = {
  origin: process.env.ALLOWED_ORIGIN || "*",
  methods: ["POST"],
  allowedHeaders: ["Content-Type"],
};
app.use(cors(corsOptions));
app.use(express.json({ limit: "20kb" })); // Limite la taille des requêtes

// Rate limiting : 30 requêtes par minute par IP
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Trop de requêtes, veuillez patienter." },
});
app.use("/api/", limiter);

// ── Client Anthropic ─────────────────────────────────────────────────────────

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// ── Route principale ─────────────────────────────────────────────────────────

app.post("/api/chat", async (req, res) => {
  const { messages, system } = req.body;

  // Validation basique
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "Messages invalides." });
  }

  // Validation des rôles et du contenu
  for (const m of messages) {
    if (!["user", "assistant"].includes(m.role)) {
      return res.status(400).json({ error: "Rôle invalide." });
    }
    if (typeof m.content !== "string" || m.content.length > 4000) {
      return res.status(400).json({ error: "Contenu invalide." });
    }
  }

  try {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      system: system || "Tu es un assistant expert en théorie des graphes et planification d'examens. Réponds en français.",
      messages,
    });

    const reply = response.content?.find(b => b.type === "text")?.text
      || "Désolé, je n'ai pas pu générer une réponse.";

    res.json({ reply });

  } catch (err) {
    console.error("Erreur Anthropic :", err.message);

    if (err.status === 401) {
      return res.status(500).json({ error: "Clé API invalide. Vérifiez le fichier .env." });
    }
    if (err.status === 429) {
      return res.status(429).json({ error: "Limite de l'API atteinte. Réessayez dans un moment." });
    }

    res.status(500).json({ error: "Erreur interne du serveur." });
  }
});

// ── Health check ─────────────────────────────────────────────────────────────

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    apiKeyConfigured: !!process.env.ANTHROPIC_API_KEY,
    timestamp: new Date().toISOString(),
  });
});

// ── Démarrage ────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`✅ Backend démarré sur http://localhost:${PORT}`);
  console.log(`   Clé API : ${process.env.ANTHROPIC_API_KEY ? "✓ configurée" : "✗ MANQUANTE (ajoutez-la dans .env)"}`);
});
