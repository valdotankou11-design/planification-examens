# 🎓 Planification d'Examens — Coloration de Graphes

Application web full-stack pour la planification automatique d'examens universitaires par algorithmes de coloration de graphes (Welsh-Powell & DSATUR).

> **Projet L2 Informatique — Théorie des Graphes | Université de Yaoundé | 2025-2026**

---

## 📁 Structure du projet

```
planification-examens/
├── frontend/          # React + Vite (interface utilisateur)
│   ├── src/App.jsx    # Application complète
│   ├── index.html
│   └── vite.config.js # Proxy → backend en dev
├── backend/           # Express.js (proxy sécurisé API Anthropic)
│   ├── server.js
│   └── .env.example   # Template de configuration
├── vercel.json        # Config déploiement Vercel
└── package.json       # Scripts racine (dev combiné)
```

---

## 🚀 Démarrage local (développement)

### 1. Cloner et installer

```bash
git clone <votre-repo>
cd planification-examens
npm run install:all
```

### 2. Configurer la clé API

```bash
cd backend
cp .env.example .env
# Éditez .env et ajoutez votre clé Anthropic :
# ANTHROPIC_API_KEY=sk-ant-...
```

Obtenez votre clé sur [console.anthropic.com](https://console.anthropic.com).

### 3. Lancer les deux serveurs

```bash
# Depuis la racine :
npm run dev
# → Frontend sur http://localhost:5173
# → Backend  sur http://localhost:3001
```

Ou séparément :
```bash
npm run dev:frontend   # port 5173
npm run dev:backend    # port 3001
```

---

## ☁️ Déploiement sur Vercel (recommandé)

### Option A — Via CLI

```bash
npm install -g vercel

# Build du frontend
cd frontend && npm run build && cd ..

# Déployer
vercel --prod
```

### Option B — Via GitHub (automatique)

1. Pushez ce dossier sur GitHub
2. Connectez le repo sur [vercel.com](https://vercel.com)
3. Dans **Settings → Environment Variables**, ajoutez :
   - `ANTHROPIC_API_KEY` = votre clé
   - `ALLOWED_ORIGIN` = `https://votre-projet.vercel.app`
4. Cliquez **Deploy** — c'est tout !

---

## 🛠️ Variables d'environnement

| Variable | Requis | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ Oui | Clé API Anthropic pour l'assistant IA |
| `PORT` | Non | Port backend (défaut : 3001) |
| `ALLOWED_ORIGIN` | Non | Domaine CORS autorisé (défaut : `*`) |

---

## 🧩 Fonctionnalités

| Onglet | Description |
|---|---|
| **Données** | Saisie/édition des UE, inscriptions étudiants, salles |
| **Graphe** | Visualisation canvas du graphe coloré + descripteurs + benchmark |
| **Planning** | Grille créneau × salle + tableau des affectations |
| **Audit** | Vérification C1–C5 (obligatoires) + S1–S2 (souhaitées) |
| **Assistant IA** | Chatbot Claude avec contexte du planning actuel |

---

## 🔒 Sécurité

- La clé API Anthropic n'est **jamais exposée** au navigateur
- Rate limiting : 30 req/min par IP
- Validation des entrées côté backend
- CORS configuré par domaine en production

---

## 📦 Stack technique

- **Frontend** : React 18, Vite 5, Canvas API
- **Backend** : Node.js, Express 4, Anthropic SDK
- **Algorithmes** : DSATUR (Brélaz 1979), Welsh-Powell (1967), Best Fit
- **Déploiement** : Vercel (serverless)
